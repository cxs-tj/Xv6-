// Physical memory allocator, for user processes,
// kernel stacks, page-table pages,
// and pipe buffers. Allocates whole 4096-byte pages.

#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "riscv.h"
#include "defs.h"

void freerange(void *pa_start, void *pa_end);

extern char end[]; // first address after kernel.
                   // defined by kernel.ld.

struct run {
  struct run *next;
};


//Add in 2022nian
int ref_count[(PHYSTOP-KERNBASE)/PGSIZE];



struct {
  struct spinlock lock;
  struct run *freelist;
} kmem;


// 检查是否是要进行cow fork的页
// 是的话返回0，否则返回-1
/*int
cowpage(pagetable_t pagetable, uint64 va)
{
  if(va > MAXVA) return -1;
  pte_t *pte = walk(pagetable, va, 0);
  if(pte == 0) return -1;
  if((*pte&PTE_V) == 0) return -1;
  return (*pte & PTE_COW) ? 0 : -1; 
}*/

// 给cow page分配物理页
/*void*
cow_alloc(pagetable_t pagetable, uint64 va)
{
  if(va % PGSIZE != 0) return 0;
  uint64 pa = walkaddr(pagetable, va);
  if(pa == 0) return 0;

  pte_t *pte = walk(pagetable, va, 0);
  if(getcnt((char*)pa) == 1){ // 获取当前物理页的计数引用，如果只是1的话，标记为可写和非cow fork
    *pte |= PTE_W;
    *pte &= ~PTE_COW;
    return (void*)pa; 
  }else{
    // 有多个进程指向这个物理页面，所以需要分配新的物理页面以供虚拟地址去指向
    char* mem;
    if((mem=kalloc()) == 0) return 0;
    // 因为刚分配新的空间，需要将孩子进程的pte的有效为先设为0
    *pte &= ~PTE_V;
    // 将旧页的内容复制到新的页里
    memmove(mem, (char*)pa, PGSIZE);
    
    // 进行映射，将虚拟地址映射到新分配的物理页面，并且标记为可写和非cow fork
    if(mappages(pagetable, va, PGSIZE, (uint64)mem, (PTE_FLAGS(*pte) | PTE_W) & ~PTE_COW) != 0){
      kfree(mem);
      *pte &= ~PTE_V;
      return 0;
    }
    // 将旧物理页的引用计数减一
    kfree((char*)PGROUNDDOWN(pa));
    return mem;
  }
}*/


void
kinit()
{
  initlock(&kmem.lock, "kmem");
  freerange(end, (void*)PHYSTOP); 
}

void
freerange(void *pa_start, void *pa_end)
{
    char *p;
    p = (char*)PGROUNDUP((uint64)pa_start);
    for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE) {
        ref_count[((uint64)p-KERNBASE)/PGSIZE]++;
        kfree(p);
        //ref_count[((uint64)p-KERNBASE)/PGSIZE]--;
    }
}

//add in 2022
void 
inc_ref(uint64 pa) {
    acquire(&kmem.lock);
    if(pa>=PHYSTOP || !ref_count[((uint64)pa-KERNBASE)/PGSIZE])
        panic("inc_ref");
    ref_count[((uint64)pa-KERNBASE)/PGSIZE]++;
    release(&kmem.lock);
}




// Free the page of physical memory pointed at by v,
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    uint64 tmp;
    struct run *r;

    if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
        panic("kfree");

    acquire(&kmem.lock);
    if(!ref_count[((uint64)pa-KERNBASE)/PGSIZE])
        panic("kfree ref");
    tmp = --ref_count[((uint64)pa-KERNBASE)/PGSIZE];
    release(&kmem.lock);

    if(tmp > 0)
        return;
    // Fill with junk to catch dangling refs.
    memset(pa, 1, PGSIZE);

    r = (struct run*)pa;

    acquire(&kmem.lock);
    r->next = kmem.freelist;
    kmem.freelist = r;
    release(&kmem.lock);
}




// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    struct run *r;

    acquire(&kmem.lock);
    r = kmem.freelist;
    if(r) {
        kmem.freelist = r->next;
        if(ref_count[((uint64)r-KERNBASE)/PGSIZE])
        panic("kalloc ref");
        ref_count[((uint64)r-KERNBASE)/PGSIZE]++;
    }
    release(&kmem.lock);

    if(r)
        memset((char*)r, 5, PGSIZE); // fill with junk
    return (void*)r;
}





